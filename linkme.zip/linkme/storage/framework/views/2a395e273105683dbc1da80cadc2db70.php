<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Laravel</title>


    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>

</head>

<body>

    <div
        class="flex flex-col p-4 justify-center items-center rounded-[2rem] overflow-hidden w-[272px] h-[572px] bg-white dark:bg-gray-800">
        <div id="avatar-preview"></div>

        <h5 id="fullName" class="mb-2 text-2xl font-bold tracking-tight text-center text-gray-900 dark:text-white">
        </h5>
        <h5 class="mb-2 text-xl font-semibold tracking-tight text-left w-full text-gray-900 dark:text-white">
            About me</h5>
        <p id="bioText" class="mb-3 text-gray-700 dark:text-gray-400 w-full "></p>
        <h5 class="mb-2 text-xl font-semibold tracking-tight text-left w-full text-gray-900 dark:text-white">
            Social media</h5>
        <div id="SocialMediaContainer" class="grid grid-cols-4 gap-4">


        </div>
        <h5 class="mb-2 text-xl font-semibold tracking-tight text-left w-full text-gray-900 dark:text-white">
            Links </h5>
        <div id="callContainer" class="w-full mb-2">

        </div>
        <div id="LinksContainer" class="w-full flex flex-col gap-2">

        </div>

    </div>



</body>

</html>
<?php /**PATH C:\Users\soufi\Documents\Flent\linkme\resources\views/detail.blade.php ENDPATH**/ ?>