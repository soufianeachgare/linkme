var socialMediaArray = {!! $types !!};
    var ActionsArrayUser = {!! $actions !!};
    var socialMediaArrayUser = {!! $social !!};